//
//  ListApp.swift
//  List
//
//  Created by Daniel Shterev on 7.02.23.
//

import SwiftUI

@main
struct ListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
